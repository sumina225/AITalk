from flask import Blueprint, request
from app.services.face_service import register_face, verify_face

face_bp = Blueprint('face', __name__)

@face_bp.route("/face-regist", methods=["POST"])
def face_register():
    data = request.json
    therapist_id = data.get("therapistId")
    return register_face(therapist_id)

@face_bp.route("/face-login", methods=["POST"])
def face_login():
    data = request.json
    therapist_id = data.get("therapistId")
    return verify_face(therapist_id)
