import cv2
import numpy as np
from deepface import DeepFace
from flask import jsonify
from app.models.user import User
from app.models.child import Child
from app.extensions import db

def cosine_similarity(a, b):
    """ 코사인 유사도 계산 (값이 1에 가까울수록 유사) """
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

def get_user_type(therapist_id):
    """ therapist_id를 기준으로 User 또는 Child를 구분 """
    return "child" if therapist_id >= 1000 else "user"

def register_face(therapist_id):
    """ 치료사(User) 또는 아동(Child)의 얼굴을 등록하여 DB에 저장 """
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        return jsonify({"message": "카메라 연결 오류"}), 503

    ret, frame = cap.read()
    if not ret:
        return jsonify({"message": "이미지 캡처 실패"}), 500

    cap.release()

    try:
        analysis = DeepFace.represent(frame, model_name="Facenet", enforce_detection=True)
        embedding = np.array(analysis[0]['embedding'], dtype=float).tobytes()

        user_type = get_user_type(therapist_id)

        if user_type == "user":
            user = User.query.filter_by(therapist_id=therapist_id).first()
            if user:
                user.face_id = embedding
            else:
                return jsonify({"message": "사용자가 존재하지 않습니다."}), 404

        elif user_type == "child":
            child = Child.query.filter_by(child_id=therapist_id).first()
            if child:
                child.face_id = embedding
            else:
                return jsonify({"message": "아동이 존재하지 않습니다."}), 404

        db.session.commit()
        return jsonify({"message": f"{user_type.capitalize()} Face ID가 등록되었습니다."}), 201

    except Exception as e:
        return jsonify({"message": f"얼굴 등록 오류: {str(e)}"}), 500

def verify_face(therapist_id):
    """ 치료사(User) 또는 아동(Child)의 얼굴을 검증 """
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        return jsonify({"message": "카메라 연결 오류"}), 503

    ret, frame = cap.read()
    if not ret:
        return jsonify({"message": "이미지 캡처 실패"}), 500

    cap.release()

    try:
        analysis = DeepFace.represent(frame, model_name="Facenet", enforce_detection=False)
        embedding = np.array(analysis[0]['embedding'], dtype=float)

        user_type = get_user_type(therapist_id)

        if user_type == "user":
            user = User.query.filter_by(therapist_id=therapist_id).first()
            if not user or user.face_id is None:
                return jsonify({"message": "일치하는 데이터가 없습니다."}), 401
            stored_embedding = np.frombuffer(user.face_id, dtype=float)

        elif user_type == "child":
            child = Child.query.filter_by(child_id=therapist_id).first()
            if not child or child.face_id is None:
                return jsonify({"message": "일치하는 데이터가 없습니다."}), 401
            stored_embedding = np.frombuffer(child.face_id, dtype=float)

        similarity = cosine_similarity(embedding, stored_embedding)

        if similarity > 0.9:
            return jsonify({"id": therapist_id, "message": f"{user_type.capitalize()} 인증 성공"}), 200
        else:
            return jsonify({"message": "일치하는 데이터가 없습니다."}), 401

    except Exception as e:
        return jsonify({"message": f"얼굴 검증 오류: {str(e)}"}), 500
