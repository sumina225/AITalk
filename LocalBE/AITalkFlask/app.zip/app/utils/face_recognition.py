import cv2
import numpy as np
import pandas as pd
from deepface import DeepFace
import os

DB_PATH = "face_db.csv"
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")


def get_next_user_id(df):
    """ 기존 사용자 수를 확인하여 새로운 user_x 이름 생성 """
    existing_users = set(df["name"]) if not df.empty else set()
    i = 1
    while f"user_{i}" in existing_users:
        i += 1
    return f"user_{i}"


def register():
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not cap.isOpened():
        print("[ERROR] 카메라를 열 수 없습니다.")
        return

    print("[INFO] 새로운 얼굴을 등록할 수 있습니다. ESC 키를 누르면 종료됩니다.")

    if not os.path.exists(DB_PATH):
        df = pd.DataFrame(columns=["name"] + [f"v{i}" for i in range(128)])
        df.to_csv(DB_PATH, index=False)
    else:
        df = pd.read_csv(DB_PATH, dtype={'name': str})

    frame_count = 0
    detect_interval = 10
    registered_count = 0

    while registered_count < 10:
        ret, frame = cap.read()
        if not ret:
            print("[ERROR] 웹캠에서 프레임을 가져올 수 없습니다.")
            break

        frame = cv2.flip(frame, 1)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        if frame_count % detect_interval == 0:
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=6, minSize=(60, 60))

            for (x, y, w, h) in faces:
                face_img = cv2.resize(frame[y:y + h, x:x + w], (200, 200))

                try:
                    analysis = DeepFace.represent(face_img, model_name="Facenet", enforce_detection=True)
                    if analysis:
                        embedding = np.array(analysis[0]['embedding'], dtype=float)

                        if not df.empty:
                            existing_embeddings = df.iloc[:, 1:].apply(pd.to_numeric, errors='coerce').values
                            distances = [np.linalg.norm(embedding - emb) for emb in existing_embeddings]

                            if min(distances) < 0.5:
                                print("[INFO] 이미 등록된 사용자와 유사합니다. 저장하지 않습니다.")
                                continue

                        name = get_next_user_id(df)
                        new_data = pd.DataFrame([[name] + embedding.tolist()])
                        new_data.to_csv(DB_PATH, mode='a', header=False, index=False, float_format='%.6f')

                        print(f"[INFO] {name} 님의 얼굴이 등록되었습니다. (총 {registered_count + 1}/10)")
                        registered_count += 1

                except Exception as e:
                    print(f"[ERROR] 얼굴 등록 오류: {e}")

        frame_count += 1
        cv2.imshow("Face Registration", frame)

        if cv2.waitKey(30) & 0xFF == 27:
            break

    cap.release()
    cv2.destroyAllWindows()
